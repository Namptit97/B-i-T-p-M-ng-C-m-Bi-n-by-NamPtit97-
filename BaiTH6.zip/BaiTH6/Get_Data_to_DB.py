import pymysql
import json

def Sensor(jsonData):
	json_Dict = json.loads(jsonData)
	SensorID = json.Dict['Sensor_ID']	
	Data_and_Time = json_Dict['Date']
	Temperature = json_Dict['Temperature']
	Humidity = json_Dict['Humidity']
	#Open database connection
	db = pymysql.connect("localhost","root","huynam","wpdb")
	cursor = db.cursor()
	sql = """insert into sensors(SensorID, Date_and_Time, Temperature, Humidity) values (%s,%s,%s,%s)"""
	val = (SensorID,Data_and_Time,Temperature,Humidity)
	cursor.execute(sql,val)
	db.commit()
	print("Sensor created new value")
	print("")

	db.close()
